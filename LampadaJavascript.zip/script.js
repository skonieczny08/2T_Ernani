const btnAlternar = document.getElementById('btn-alternar')
imgLampada = document.getElementById('lampada')
const baseUrl = "https://cee47dad-43db-48f6-99d5-accb84855b54-00-hkjcfdbiyh58.worf.replit.dev/"

btnAlternar.addEventListener('click', function() {
  if (imgLampada.src = baseUrl + 'lampada0.png') {
    imgLampada.src = "lampada2.png"
  } else {
    imgLampada.src = "lampada0.png"
  }

})

//FUNCOES COM RET0RNO 
//SÃO FUNCOES QUE PERMITEM RETER O VALOR PROCESSADO
//PARA USO POSTERIOR

// const nome = 'Carla'
// function retornaDados() {
//   // codigo com retorno
//   return nome.toUpperCase()
//   console.log('testando...') // INACANÇÁVEL
//A PARTIR DESSA LINHA NÃO RETORNA MAIS NADA...
// }
// const dados = retornaDados()
// alert(dados)


/**
 *  CRIE UMA FUNCAO QUE RECEBA (nome, idade, cpf)
 * RETORNE OS DADOS FORMATADOS COM UMA MENSAGEM COM TODOS OS DADOS
 * ARMAZENE EM UMA VARIAVEL E IMPRIMA COM CONSOLE.LOG
 */

const nome = 'Carla'
const idade = 21
const cpf = '123.456.789-00'
function retornaDados(nome, idade, cpf) {
  return 'Olá ' + nome + ' sua idade é ' + idade + ' e seu CPF é ' + cpf
}
const dados = retornaDados('Carla', 21, '123.456.789-00')
alert(dados)
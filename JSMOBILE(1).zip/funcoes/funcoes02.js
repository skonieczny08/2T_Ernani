// DECLARAÇÃO OU CRIAÇÃO
// function soma(n1, n2) {
//   if (typeof n1 === 'number' && typeof n2 === 'number') {
//     const res = n1 + n2;
//     alert('0 resultado foi: ' + res )
//   } else {
//     alert('Por favor insira um número válido!')
//   }
// }
// // INVOCAÇÃO OU CHAMAR
// soma('melancia',3)
// soma(9,'5')
// soma(32,9)
// soma(8,7)

// CRIE UMA FUNÇÃO QUE RECEBA UM PARÂMETROS:
// NOME, ALTURA
// CHEQUE SE A ALTURA É DO TIPO NUMÉRICO "number"
// SE AS DUAS CONDIÇÕES FOREM VERDADEIRAS, RETORNE O SEGUINTE:
// "OLÁ" + nome + " ua altura é " + altura



function dados(nome, altura) {
  if (typeof nome === 'string' && typeof altura === 'number') {
    const res = 'Olá ' + nome + ' sua altura é ' + altura
    alert(res)
  }

  else {
    alert('Por favor, insira seus dados corretamente!')
  }
}
// dados('Janaina', 1.72)
// dados(75, 1.72)

//CRIE UMA FUNCAO QUE RECEBA UM NUMERO COMO PARAMETRO
/* 
  CASO (IF) (N % 2 === 0, IMPRIMA "O numero " + NUMERO + " é par" 
  CASO CONTRARIO (ELSE), IMPRIMA "O numero " + NUMERO + " é impar"
  */

function parOuImpar(x) {
  if (typeof x === 'number') {
    if (x % 2 === 0) {
      alert('Olá, o número ' + x + ' é par!')
    } else {
      alert('Olá, o número ' + x + ' é impar!')
    }
  } else {
    alert('Ṕor favor, digite um número válido !')
  }
}
parOuImpar(2)
parOuImpar(5)
parOuImpar("Laranja")





/**
 * FUNÇÕES: São blocos de código que podem ser reaproveitados.
 * Funções podem ou não ter nomes.
 * Podem ou não ter parâmetros.
 */
// CRIAÇÃO OU DECLARAÇÃO DE FUNÇÕES
function dizOla(nome) {
     // código
     console.log('Olá! ' + nome)
}
// INVOCAR / CHAMAR FUNÇÕES
//dizOla('Pamela')
//dizOla('Thamily')
//dizOla('José')

// ADIÇÃO
function somaDoisNumeros(x, y) {
     const soma = x + y
     console.log(soma)
}
somaDoisNumeros(2, 3)
somaDoisNumeros(5, 6)

// SUBTRAÇÃO
function subtraiDoisNumeros(x, y) {
     const subtrai = x - y
     console.log(subtrai)
}
subtraiDoisNumeros(8, 3)
subtraiDoisNumeros(9, 6)

// MULTIPLICAÇÃO
function multiplicaDoisNumeros(x, y) {
     const multiplica = x * y
     console.log(multiplica)
}
multiplicaDoisNumeros(8, 9)
multiplicaDoisNumeros(9, 4)

//DIVISÃO
function divideDoisNumeros(x, y) {
     const divide = x / y
     console.log(divide)
}
divideDoisNumeros(8, 2)
divideDoisNumeros(8, 4) 
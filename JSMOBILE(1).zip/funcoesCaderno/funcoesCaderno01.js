function dados(nome, sobrenome) {
  if (typeof nome === 'string' && typeof sobrenome === 'string') {
    const res = 'Olá ' + nome + ' ' + sobrenome + '!'
    alert(res)
  } else {
    alert('Digite seu nome corretamente!')
  }
}
// dados ('Carla', 'Almeida')
// dados (87, "Carla")


function dados(nome, altura) {
  if (typeof nome === 'string' && typeof altura === 'number') {
    const res = 'Olá ' + nome + ' ' + 'sua altura é ' + altura
    alert(res)
  } else {
    alert('Por favor, digite seus dados corretamente!')
  }
// }
// dados('Carla', 1.67)
// dados(18, 1.67)
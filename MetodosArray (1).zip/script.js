// MÉTODOS DE ARRAY
const comidas = ['churrasco', 'pizza']
comidas[3] = 'sushi' //MANUAL
comidas.push('beringela') //EMPURRANDO UM VALOR PARA O FINAL DA LISTA 
comidas.pop() //REMOVENDO UM VALOR DO FINAL DA LISTA
comidas.shift() // RETIRAM UM ELEMENTO DO INICIO
comidas.unshift('lasanha') // INSERIR UM VALOR NO INICIO DA LISTA

const tamanho = comidas.length // RETORNA O TAMANHO DA LISTA
console.log("Existem " + tamanho + " itens na lista") // CONTAGEM DOS ITENS

console.log(comidas)

